r'''
# University of Colorado: Intro to AI 2022


### All classes needed for HW2 are in this submodule

The main class you will be accessing is `colorado_intro_ai.hw2.robot`
 

 '''



